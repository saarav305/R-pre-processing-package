#' Univariate visualizations for numeric columns
#'
#' Creates boxplots, a zero-percent barplot, and histograms for each numeric
#' column in a data frame. Histograms are saved across multiple PDF pages if needed.
#'
#' @param df A data frame.
#' @param show_plots Logical; if TRUE, draw plots in the current graphics device.
#' @param save_pdf Logical; if TRUE, save PDFs to `out_dir`.
#' @param out_dir Character; folder where PDFs should be saved.
#' @param prefix Character; filename prefix for saved PDFs.
#' @param hist_nrow Number of histogram rows per page.
#' @param hist_ncol Number of histogram columns per page.
#' @param boxplot_width Width of saved boxplot PDF in inches.
#' @param boxplot_height Height of saved boxplot PDF in inches.
#' @param barplot_width Width of saved zero-percent barplot PDF in inches.
#' @param barplot_height Height of saved zero-percent barplot PDF in inches.
#' @param hist_width Width of saved histogram PDF in inches.
#' @param hist_height Height of saved histogram PDF in inches.
#'
#' @return Invisibly returns a list with zero percentages, numeric column names,
#' number of histograms, number of histogram pages, and saved file paths.
#'
#' @examples
#' univar_visualize_df(iris, save_pdf = TRUE, out_dir = tempdir())
#'
#' @export
univar_visualize_df <- function(df,
                                show_plots = TRUE,
                                save_pdf = FALSE,
                                out_dir = "~",
                                prefix = "univar",
                                hist_nrow = 4,
                                hist_ncol = 5,
                                boxplot_width = 12,
                                boxplot_height = 8,
                                barplot_width = 12,
                                barplot_height = 8,
                                hist_width = 12,
                                hist_height = 10) {
  
  if (!is.data.frame(df)) {
    stop("`df` must be a data frame.", call. = FALSE)
  }
  
  num <- numeric_df(df)
  
  if (ncol(num) == 0L) {
    stop("No numeric columns found in `df`.", call. = FALSE)
  }
  
  zero_percent <- vapply(num, function(x) {
    n <- sum(!is.na(x))
    if (n == 0L) return(NA_real_)
    100 * sum(x == 0, na.rm = TRUE) / n
  }, numeric(1))
  
  plot_boxplot <- function() {
    op <- par(no.readonly = TRUE)
    on.exit(par(op), add = TRUE)
    
    par(mar = c(10, 4, 4, 1) + 0.1)
    
    boxplot(
      num,
      las = 2,
      main = "Boxplots for Numeric Variables"
    )
  }
  
  plot_zero_barplot <- function() {
    op <- par(no.readonly = TRUE)
    on.exit(par(op), add = TRUE)
    
    par(mar = c(10, 4, 4, 1) + 0.1)
    
    barplot(
      zero_percent,
      names.arg = names(zero_percent),
      las = 2,
      main = "Percent of Zeros per Numeric Variable",
      ylab = "Percent (%)"
    )
  }
  
  plot_histograms <- function() {
    vars <- names(num)
    
    per_page <- hist_nrow * hist_ncol
    n_pages <- ceiling(length(vars) / per_page)
    
    message("Numeric columns found: ", length(vars))
    message("Histograms per page: ", per_page)
    message("Histogram pages created: ", n_pages)
    
    for (pg in seq_len(n_pages)) {
      
      idx_start <- (pg - 1L) * per_page + 1L
      idx_end <- min(pg * per_page, length(vars))
      vars_page <- vars[idx_start:idx_end]
      
      op <- par(no.readonly = TRUE)
      on.exit(par(op), add = TRUE)
      
      par(
        mfrow = c(hist_nrow, hist_ncol),
        mar = c(3, 3, 3, 1) + 0.1,
        oma = c(0, 0, 4, 0)
      )
      
      for (v in vars_page) {
        hist(
          num[[v]],
          main = v,
          xlab = "",
          col = "gray85",
          border = "white"
        )
      }
      
      empty_panels <- per_page - length(vars_page)
      
      if (empty_panels > 0L) {
        for (i in seq_len(empty_panels)) {
          plot.new()
        }
      }
      
      mtext(
        paste0(
          "Histograms for Numeric Variables: Page ",
          pg,
          " of ",
          n_pages,
          " | Variables ",
          idx_start,
          "-",
          idx_end,
          " of ",
          length(vars)
        ),
        outer = TRUE,
        font = 2,
        cex = 1.2
      )
    }
  }
  
  out_files <- c()
  
  if (show_plots) {
    plot_boxplot()
    plot_zero_barplot()
    plot_histograms()
    
    message(
      "Note: In RStudio's plot pane, you may only see one histogram page at a time. ",
      "Use save_pdf = TRUE to create a full multipage histogram PDF."
    )
  }
  
  if (save_pdf) {
    out_dir <- path.expand(out_dir)
    
    if (!dir.exists(out_dir)) {
      dir.create(out_dir, recursive = TRUE)
    }
    
    boxplot_file <- file.path(
      out_dir,
      paste0(prefix, "_boxplots.pdf")
    )
    
    grDevices::pdf(
      boxplot_file,
      width = boxplot_width,
      height = boxplot_height
    )
    plot_boxplot()
    grDevices::dev.off()
    
    barplot_file <- file.path(
      out_dir,
      paste0(prefix, "_zero_percent_barplot.pdf")
    )
    
    grDevices::pdf(
      barplot_file,
      width = barplot_width,
      height = barplot_height
    )
    plot_zero_barplot()
    grDevices::dev.off()
    
    hist_file <- file.path(
      out_dir,
      paste0(prefix, "_histograms_all_numeric_variables.pdf")
    )
    
    grDevices::pdf(
      hist_file,
      width = hist_width,
      height = hist_height,
      onefile = TRUE
    )
    plot_histograms()
    grDevices::dev.off()
    
    out_files <- c(
      boxplot_pdf = boxplot_file,
      zero_barplot_pdf = barplot_file,
      histogram_pdf = hist_file
    )
    
    message("Saved histogram PDF here: ", hist_file)
    message("This PDF contains all histogram pages, not just the final page.")
  }
  
  invisible(list(
    zero_percent = zero_percent,
    numeric_columns = names(num),
    n_numeric_columns = ncol(num),
    n_histograms = ncol(num),
    histograms_per_page = hist_nrow * hist_ncol,
    n_histogram_pages = ceiling(ncol(num) / (hist_nrow * hist_ncol)),
    files = out_files
  ))
}