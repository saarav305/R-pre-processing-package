#' Skewness
#'
#' Computes skewness for a numeric vector or for each numeric column
#' of a data frame. Missing values are ignored.
#'
#' @param x A numeric vector or a data frame.
#'
#' @return
#' If `x` is a numeric vector, returns one numeric skewness value.
#' If `x` is a data frame, returns a data frame with one skewness value
#' per numeric column.
#'
#' @examples
#' skewness(c(1, 2, 3, 4, 100))
#' skewness(iris)
#'
#' @export
skewness <- function(x) {
  
  calc_skewness <- function(v) {
    
    if (!is.numeric(v)) {
      stop("skewness() requires numeric data.")
    }
    
    v <- v[!is.na(v)]
    N <- length(v)
    
    if (N < 2L) {
      return(NA_real_)
    }
    
    v_mean <- mean(v)
    v_sd <- sqrt(sum((v - v_mean)^2) / N)
    
    if (v_sd == 0) {
      return(NA_real_)
    }
    
    numerator <- sum((v - v_mean)^3) / N
    denominator <- v_sd^3
    
    numerator / denominator
  }
  
  # Case 1: x is a data frame
  if (is.data.frame(x)) {
    
    num <- numeric_df(x)
    
    if (ncol(num) == 0L) {
      return(data.frame(skewness = numeric(0)))
    }
    
    out <- data.frame(
      skewness = vapply(num, calc_skewness, numeric(1))
    )
    
    rownames(out) <- names(num)
    
    return(out)
  }
  
  # Case 2: x is one numeric vector
  if (is.numeric(x)) {
    return(calc_skewness(x))
  }
  
  stop("skewness() requires either a numeric vector or a data frame.")
}