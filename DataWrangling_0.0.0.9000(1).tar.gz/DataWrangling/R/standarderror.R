#' Standard error of sample skewness
#'
#' Computes the large-sample approximation to the standard error of sample
#' skewness for a numeric vector or for each numeric column of a data frame.
#' Missing values are ignored.
#'
#' @param x A numeric vector or a data frame.
#'
#' @return
#' If `x` is a numeric vector, returns one numeric standard error value.
#' If `x` is a data frame, returns a data frame with one standard error value
#' per numeric column.
#'
#' @details The estimate is
#' \deqn{\sqrt{\frac{6N(N-1)}{(N-2)(N+1)(N+3)}} ,}
#' where \eqn{N} is the number of non-missing values in \code{x}.
#' The expression is used for \eqn{N > 3}. Otherwise, \code{NA} is returned.
#'
#' @examples
#' skew_se(c(1, 2, 3, 4, 5))
#' skew_se(c(1, 2, NA, 4, 5))
#' skew_se(iris)
#'
#' @seealso \code{\link{skewness}}
#'
#' @export
skew_se <- function(x) {
  
  calc_skew_se <- function(v) {
    
    if (!is.numeric(v)) {
      stop("skew_se() requires numeric data.")
    }
    
    v <- v[!is.na(v)]
    N <- length(v)
    
    if (N <= 3L) {
      return(NA_real_)
    }
    
    sqrt(6 * N * (N - 1) / ((N - 2) * (N + 1) * (N + 3)))
  }
  
  # Case 1: x is a data frame
  if (is.data.frame(x)) {
    
    num <- numeric_df(x)
    
    if (ncol(num) == 0L) {
      return(data.frame(skew_se = numeric(0)))
    }
    
    out <- data.frame(
      skew_se = vapply(num, calc_skew_se, numeric(1))
    )
    
    rownames(out) <- names(num)
    
    return(out)
  }
  
  # Case 2: x is one numeric vector
  if (is.numeric(x)) {
    return(calc_skew_se(x))
  }
  
  stop("skew_se() requires either a numeric vector or a data frame.")
}