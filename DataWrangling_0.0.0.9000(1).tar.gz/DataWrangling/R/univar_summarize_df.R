#' Column-wise summary with outliers, normality, and skewness
#'
#' @description
#' Produces a tidy, one-row-per-variable summary of a data frame. For numeric
#' columns, it reports distributional statistics (min, max, range, median, IQR),
#' percent zeros, outlier counts (|z|), and skewness metrics (skewness, SE,
#' and skew z-score). For all columns it reports counts of non-missing values,
#' missing values, unique values, and whether duplicates exist within the column.
#' Shapiro–Wilk p-values (and a normality flag) are computed where valid.
#'
#' @param df A data.frame-like object (data.frame, tibble, data.table, matrix,
#'   list, or a single vector). Non-data.frame inputs are coerced with
#'   \code{as.data.frame()}.
#' @param alpha Numeric scalar (default `0.05`). Threshold for the Shapiro–Wilk
#'   normality test; `Is_Normal` is `TRUE` if `Shapiro_p > alpha`.
#' @param z_thresh Numeric scalar (default `3`). Absolute z-score threshold used
#'   to count outliers and to flag skewness via `Is_Skewed` (`abs(Skew_Z) > z_thresh`).
#'
#' @return A `data.frame` with one row per column of `df` and columns:
#' \code{Variable, Type, N, Missing_Count, Unique_Values, Has_Duplicates,
#' Min, Max, Range, Median, IQR, Zero_Percent, Outlier_Count,
#' Shapiro_p, Is_Normal, Skewness, Skew_SE, Skew_Z, Is_Skewed}.
#'
#' @examples
#' \dontrun{
#'   DataWrangling::univar_summarize_df(mtcars)
#'   DataWrangling::univar_summarize_df(as.matrix(mtcars))
#'   DataWrangling::univar_summarize_df(iris$Sepal.Length)
#' }
#'
#' @importFrom stats IQR median sd shapiro.test
#' @export
#' @importFrom stats IQR median sd shapiro.test
#' @export
univar_summarize_df <- function(df, alpha = 0.05, z_thresh = 3,
                                do_shapiro = TRUE, do_skew = TRUE) {
  # helpers ---------------------------------------------------------------
  zscore <- function(x) {
    x <- as.numeric(x)
    m <- base::mean(x, na.rm = TRUE); s <- stats::sd(x, na.rm = TRUE)
    if (is.na(s) || s == 0) return(rep(NA_real_, length(x)))
    (x - m) / s
  }
  skewness_ <- function(x) {
    x <- as.numeric(x); x <- x[is.finite(x)]; n <- length(x)
    if (n < 3) return(NA_real_)
    m <- base::mean(x); s <- stats::sd(x); if (is.na(s) || s == 0) return(NA_real_)
    m3 <- base::mean((x - m)^3)
    (sqrt(n * (n - 1)) / (n - 2)) * (m3 / (s^3))
  }
  skew_se_ <- function(x) {
    x <- as.numeric(x); n <- sum(is.finite(x)); if (n < 3) return(NA_real_)
    sqrt(6 / n)
  }
  skew_zscore_ <- function(x) {
    s <- skewness_(x); se <- skew_se_(x)
    if (is.na(s) || is.na(se) || se == 0) return(NA_real_)
    s / se
  }
  safe_shapiro_pval <- function(x) {
    x <- as.numeric(x); x <- x[is.finite(x)]
    n <- length(x)
    if (!do_shapiro || n < 3 || n > 5000) return(NA_real_)
    if (stats::sd(x) == 0) return(NA_real_)
    stats::shapiro.test(x)$p.value
  }

  # coerce input ----------------------------------------------------------
  if (!is.data.frame(df)) {
    if (is.vector(df) || is.factor(df)) {
      df <- data.frame(value = df)
    } else if (inherits(df, c("matrix", "array", "list"))) {
      df <- as.data.frame(df, stringsAsFactors = FALSE)
    } else {
      stop("univar_summarize_df(): `df` must be data frame-like. Got class: ",
           paste(class(df), collapse = ", "), call. = FALSE)
    }
  }

  is_num     <- vapply(df, is.numeric, logical(1))
  N_nonmiss  <- vapply(df, function(x) sum(!is.na(x)), integer(1))
  num_min    <- ifelse(is_num, vapply(df, function(x) min(x, na.rm=TRUE), numeric(1)), NA_real_)
  num_max    <- ifelse(is_num, vapply(df, function(x) max(x, na.rm=TRUE), numeric(1)), NA_real_)
  num_range  <- num_max - num_min
  num_median <- ifelse(is_num, vapply(df, function(x) stats::median(x, na.rm=TRUE), numeric(1)), NA_real_)
  num_iqr    <- ifelse(is_num, vapply(df, function(x) stats::IQR(x, na.rm=TRUE), numeric(1)), NA_real_)

  zero_pct <- ifelse(is_num,
                     vapply(df, function(x) {
                       n <- sum(!is.na(x)); if (n == 0) return(NA_real_)
                       100 * sum(x == 0, na.rm = TRUE) / n
                     }, numeric(1)), NA_real_)

  has_dups <- vapply(df, function(x) any(duplicated(x[!is.na(x)])), logical(1))

  outlier_count <- ifelse(is_num,
                          vapply(df, function(x) sum(abs(zscore(x)) > z_thresh, na.rm=TRUE),
                                 integer(1)),
                          NA_integer_)

  shapiro_p <- vapply(df, function(x) if (is.numeric(x)) safe_shapiro_pval(x) else NA_real_,
                      numeric(1))
  is_normal <- ifelse(is.na(shapiro_p), NA, shapiro_p > alpha)

  skew_val    <- ifelse(is_num & do_skew, vapply(df, skewness_,    numeric(1)), NA_real_)
  skew_se_val <- ifelse(is_num & do_skew, vapply(df, skew_se_,     numeric(1)), NA_real_)
  skew_z      <- ifelse(is_num & do_skew, vapply(df, skew_zscore_, numeric(1)), NA_real_)
  is_skewed   <- ifelse(is_num & do_skew, abs(skew_z) > z_thresh, NA)

  data.frame(
    Variable       = names(df),
    Type           = ifelse(is_num, "numeric", vapply(df, function(x) class(x)[1], character(1))),
    N              = N_nonmiss,
    Missing_Count  = vapply(df, function(x) sum(is.na(x)), integer(1)),
    Unique_Values  = vapply(df, function(x) length(unique(x[!is.na(x)])), integer(1)),
    Has_Duplicates = has_dups,
    Min            = num_min,
    Max            = num_max,
    Range          = num_range,
    Median         = num_median,
    IQR            = num_iqr,
    Zero_Percent   = zero_pct,
    Outlier_Count  = outlier_count,
    Shapiro_p      = shapiro_p,
    Is_Normal      = is_normal,
    Skewness       = skew_val,
    Skew_SE        = skew_se_val,
    Skew_Z         = skew_z,
    Is_Skewed      = is_skewed,
    stringsAsFactors = FALSE,
    row.names = NULL
  )
}
