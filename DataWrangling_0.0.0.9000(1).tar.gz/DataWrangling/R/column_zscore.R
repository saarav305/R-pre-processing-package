#' Compute z-scores for each numeric column of a data frame
#'
#' Applies [zscore()] to every numeric column in `df`.
#'
#' @param df A data frame.
#'
#' @return A data frame containing z-scored numeric columns.
#'
#' @examples
#' column_zscore(iris)
#'
#' @export
column_zscore <- function(df) {
  num <- numeric_df(df)
  
  if (ncol(num) == 0L) {
    rownames(num) <- rownames(df)
    return(num)
  }
  
  out <- as.data.frame(lapply(num, zscore))
  
  rownames(out) <- rownames(df)
  
  out
}