#' Safe Shapiro-Wilk p-values for a vector or data frame
#'
#' If `x` is a numeric vector, returns one Shapiro-Wilk p-value.
#' If `x` is a data frame, applies the test to each numeric column and returns
#' one p-value per numeric column.
#'
#' Returns NA when the test is not applicable:
#' - fewer than 3 non-missing values
#' - all values are equal
#' - more than `sample_size` values and `subsample = FALSE`
#'
#' @param x A numeric vector or a data frame.
#' @param na.rm Logical; drop NAs before testing. Default is TRUE.
#' @param subsample Logical; if TRUE and length is greater than `sample_size`,
#'   randomly sample `sample_size` values before testing. Default is TRUE.
#' @param sample_size Integer; maximum size for Shapiro-Wilk. Default is 5000.
#'
#' @return If `x` is a numeric vector, a single numeric p-value.
#' If `x` is a data frame, a named numeric vector of p-values, one per numeric column.
#'
#' @examples
#' set.seed(1)
#' safe_shapiro_pval(rnorm(100))
#'
#' safe_shapiro_pval(iris)
#'
#' @export
safe_shapiro_pval <- function(x, na.rm = TRUE, subsample = TRUE, sample_size = 5000L) {
  
  sample_size <- as.integer(sample_size)
  
  if (sample_size < 3L) {
    stop("`sample_size` must be at least 3.", call. = FALSE)
  }
  
  if (sample_size > 5000L) {
    sample_size <- 5000L
  }
  
  # Case 1: data frame input
  if (is.data.frame(x)) {
    num <- numeric_df(x)
    
    if (ncol(num) == 0L) {
      return(numeric())
    }
    
    return(vapply(
      num,
      safe_shapiro_pval,
      FUN.VALUE = numeric(1),
      na.rm = na.rm,
      subsample = subsample,
      sample_size = sample_size
    ))
  }
  
  # Case 2: numeric vector input
  if (!is.numeric(x)) {
    stop("`x` must be a numeric vector or a data frame.", call. = FALSE)
  }
  
  if (na.rm) {
    x <- x[!is.na(x)]
  }
  
  n <- length(x)
  
  if (n < 3L) {
    return(NA_real_)
  }
  
  if (length(unique(x)) == 1L) {
    return(NA_real_)
  }
  
  if (n > sample_size) {
    if (!subsample) {
      return(NA_real_)
    }
    
    x <- sample(x, sample_size)
  }
  
  stats::shapiro.test(x)$p.value
}