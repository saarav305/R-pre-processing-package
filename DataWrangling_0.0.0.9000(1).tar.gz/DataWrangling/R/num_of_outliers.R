#' Count z-score outliers by column in a data frame
#'
#' Applies [z_outlier()] to each numeric column of `df` and returns a named
#' integer vector of counts.
#'
#' @param df A data frame.
#' @param threshold Positive numeric; two-sided z cutoff (default 3).
#' @param na.rm Logical; ignore NAs when counting (default TRUE).
#'
#' @return An integer named vector (one entry per numeric column).
#'
#' @examples
#' num_of_outliers_df(iris, threshold = 3)
#'
#' @seealso [zscore()], [z_outlier()]
#' @export
num_of_outliers_df <- function(df, threshold = 3, na.rm = TRUE) {
  num <- numeric_df(df)
  if (ncol(num) == 0L) return(integer())
  zmat <- as.data.frame(lapply(num, zscore, na.rm = na.rm))
  vapply(zmat, z_outlier, FUN.VALUE = integer(1), threshold = threshold,
         use_z = FALSE, na.rm = na.rm)
}
