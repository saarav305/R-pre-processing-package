#' Z-score standardization
#'
#' Returns standardized values \eqn{z = (x - \bar{x}) / s}, where
#' \eqn{\bar{x}} is the sample mean and \eqn{s} is the sample standard
#' deviation.
#'
#' @param x Numeric vector.
#' @param na.rm Logical; if TRUE, NAs are removed when computing mean and sd.
#'
#' @return A numeric vector of z-scores with the same length and names as `x`.
#'
#' @examples
#' zscore(c(1, 2, 3, 4, 5))
#'
#' @export
zscore <- function(x, na.rm = TRUE) {
  
  if (!is.numeric(x)) {
    stop("`x` must be numeric.", call. = FALSE)
  }
  
  x_names <- names(x)
  
  mu <- base::mean(x, na.rm = na.rm)
  s <- stats::sd(x, na.rm = na.rm)
  
  if (!is.finite(s) || s == 0) {
    warning("zscore: standard deviation is zero or non-finite; returning NA.")
    out <- rep(NA_real_, length(x))
    names(out) <- x_names
    return(out)
  }
  
  out <- (x - mu) / s
  names(out) <- x_names
  
  out
}