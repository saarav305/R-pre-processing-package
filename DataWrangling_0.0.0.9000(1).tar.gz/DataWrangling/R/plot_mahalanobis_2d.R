#' Plot 2D Mahalanobis ellipse and outliers
#'
#' Creates a 2D scatterplot for two numeric variables with the corresponding
#' Mahalanobis ellipse and outlier flags.
#'
#' @param df A data frame.
#' @param x Name of first numeric column.
#' @param y Name of second numeric column.
#' @param id_col Optional column name for sample IDs.
#' @param alpha Significance level for the ellipse cutoff. Default is 0.001.
#' @param na.rm Logical; if TRUE, remove rows with missing values.
#' @param label_outliers Logical; if TRUE, label outlier points.
#'
#' @return A ggplot object.
#'
#' @examples
#' plot_mahalanobis_2d(iris, "Sepal.Length", "Sepal.Width")
#'
#' @export
plot_mahalanobis_2d <- function(df, x, y, id_col = NULL,
                                alpha = 0.001,
                                na.rm = TRUE,
                                label_outliers = TRUE) {
  
  if (!is.data.frame(df)) {
    stop("`df` must be a data.frame.", call. = FALSE)
  }
  
  if (!all(c(x, y) %in% names(df))) {
    stop("`x` and `y` must be column names in `df`.", call. = FALSE)
  }
  
  if (!is.numeric(df[[x]]) || !is.numeric(df[[y]])) {
    stop("`x` and `y` must both be numeric columns.", call. = FALSE)
  }
  
  if (!is.null(id_col) && !id_col %in% names(df)) {
    stop("`id_col` was not found in `df`.", call. = FALSE)
  }
  
  tmp <- df[, c(x, y), drop = FALSE]
  keep <- stats::complete.cases(tmp)
  
  if (!na.rm && !all(keep)) {
    stop("Missing values found in selected columns. Set `na.rm = TRUE` to remove them.", call. = FALSE)
  }
  
  tmp <- tmp[keep, , drop = FALSE]
  idx <- which(keep)
  
  ids <- if (!is.null(id_col)) {
    as.character(df[[id_col]][keep])
  } else if (!is.null(rownames(df)) && any(nzchar(rownames(df)))) {
    rownames(df)[keep]
  } else {
    as.character(idx)
  }
  
  center <- colMeans(tmp)
  cov_mat <- stats::cov(tmp)
  
  md2 <- tryCatch(
    stats::mahalanobis(tmp, center = center, cov = cov_mat),
    error = function(e) {
      stop("Covariance matrix could not be inverted. Check for perfectly collinear columns.", call. = FALSE)
    }
  )
  
  cutoff <- stats::qchisq(1 - alpha, df = 2)
  
  plot_df <- data.frame(
    Index = idx,
    ID = ids,
    x = tmp[[x]],
    y = tmp[[y]],
    MD2 = as.numeric(md2),
    Cutoff = cutoff,
    Is_Outlier = as.numeric(md2) > cutoff,
    stringsAsFactors = FALSE
  )
  
  eig <- eigen(cov_mat)
  angles <- seq(0, 2 * pi, length.out = 200)
  circle <- cbind(cos(angles), sin(angles))
  A <- eig$vectors %*% diag(sqrt(pmax(eig$values, 0)), nrow = 2)
  ellipse_xy <- sweep((circle %*% t(A)) * sqrt(cutoff), 2, center, "+")
  
  ellipse_df <- data.frame(
    x = ellipse_xy[, 1],
    y = ellipse_xy[, 2]
  )
  
  p <- ggplot2::ggplot(plot_df, ggplot2::aes(x = x, y = y)) +
    ggplot2::geom_point(ggplot2::aes(shape = Is_Outlier), size = 2.5) +
    ggplot2::geom_path(
      data = ellipse_df,
      ggplot2::aes(x = x, y = y),
      inherit.aes = FALSE,
      linetype = "dashed"
    ) +
    ggplot2::labs(
      x = x,
      y = y,
      title = "2D Mahalanobis Outlier Plot",
      subtitle = paste0(
        "Ellipse based on ",
        x,
        " and ",
        y,
        "; alpha = ",
        alpha,
        "; cutoff = ",
        round(cutoff, 3)
      ),
      shape = "Outlier"
    ) +
    ggplot2::theme_classic()
  
  if (label_outliers) {
    p <- p +
      ggplot2::geom_text(
        data = plot_df[plot_df$Is_Outlier, , drop = FALSE],
        ggplot2::aes(label = ID),
        vjust = -0.7,
        size = 3
      )
  }
  
  p
}