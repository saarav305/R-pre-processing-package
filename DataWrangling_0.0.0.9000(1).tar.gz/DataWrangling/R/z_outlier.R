#' Count z-score outliers
#'
#' Counts how many observations exceed a two-sided z-score threshold.
#'
#' If `x` is a numeric vector, the function returns one outlier count.
#' If `x` is a data frame, the function returns one outlier count for each
#' numeric column.
#'
#' @param x A numeric vector or a data frame.
#' @param threshold Positive numeric scalar; two-sided cutoff. Default is `3`.
#' @param use_z Logical; if `TRUE`, compute z-scores using [zscore()] first.
#'   If `FALSE`, treat `x` as already being z-scores.
#' @param na.rm Logical; if `TRUE`, ignore `NA`s when counting outliers.
#'
#' @return
#' If `x` is a numeric vector, returns one integer count.
#' If `x` is a data frame, returns a data frame with one count per numeric column.
#'
#' @examples
#' set.seed(42)
#' x <- c(rnorm(100), 10)
#' z_outlier(x)
#'
#' z <- zscore(x)
#' z_outlier(z, use_z = FALSE)
#'
#' z_outlier(iris)
#'
#' @seealso [zscore()]
#'
#' @export
z_outlier <- function(x, threshold = 3, use_z = TRUE, na.rm = TRUE) {
  
  if (!is.numeric(threshold) || length(threshold) != 1L || threshold < 0) {
    stop("threshold must be a single non-negative number.")
  }
  
  if (!is.logical(use_z) || length(use_z) != 1L) {
    stop("use_z must be TRUE or FALSE.")
  }
  
  if (!is.logical(na.rm) || length(na.rm) != 1L) {
    stop("na.rm must be TRUE or FALSE.")
  }
  
  count_outliers <- function(v) {
    
    if (!is.numeric(v)) {
      stop("z_outlier() requires numeric data.")
    }
    
    z <- if (use_z) {
      zscore(v, na.rm = na.rm)
    } else {
      v
    }
    
    as.integer(sum(abs(z) > threshold, na.rm = na.rm))
  }
  
  # Case 1: x is a data frame
  if (is.data.frame(x)) {
    
    num <- numeric_df(x)
    
    if (ncol(num) == 0L) {
      return(data.frame(n_outliers = integer(0)))
    }
    
    out <- data.frame(
      n_outliers = vapply(num, count_outliers, integer(1))
    )
    
    rownames(out) <- names(num)
    
    return(out)
  }
  
  # Case 2: x is one numeric vector
  if (is.numeric(x)) {
    return(count_outliers(x))
  }
  
  stop("z_outlier() requires either a numeric vector or a data frame.")
}