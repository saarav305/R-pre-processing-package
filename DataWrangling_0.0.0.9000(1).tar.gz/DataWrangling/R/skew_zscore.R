#' Skewness z-score for a vector or data frame
#'
#' Computes the z-score of sample skewness:
#' \deqn{z = \hat{\gamma}_1 \; / \; \mathrm{SE}(\hat{\gamma}_1),}
#' where \eqn{\hat{\gamma}_1} is the sample skewness from [skewness()]
#' and \eqn{\mathrm{SE}(\hat{\gamma}_1)} is from [skew_se()].
#'
#' If `x` is a numeric vector, returns one skewness z-score.
#' If `x` is a data frame, applies the calculation to each numeric column and
#' returns one skewness z-score per numeric column.
#'
#' @param x A numeric vector or a data frame.
#' Missing values are removed with [stats::na.omit()] before calculations.
#'
#' @return If `x` is a numeric vector, a single numeric skewness z-score.
#' If `x` is a data frame, a named numeric vector with one skewness z-score per
#' numeric column.
#'
#' Returns `NA_real_` with a warning if fewer than 4 non-missing observations are
#' available.
#'
#' @details This function is a wrapper around [skewness()] and [skew_se()].
#' It returns \code{skewness(x) / skew_se(x)}.
#'
#' @seealso [skewness()], [skew_se()], [numeric_df()]
#'
#' @examples
#' set.seed(1)
#' skew_zscore(rnorm(100))
#' skew_zscore(c(1, 2, 3, 4, 100))
#' skew_zscore(iris)
#'
#' @export
skew_zscore <- function(x) {
  
  # Case 1: data frame input
  if (is.data.frame(x)) {
    num <- numeric_df(x)
    
    if (ncol(num) == 0L) {
      return(numeric())
    }
    
    return(vapply(
      num,
      skew_zscore,
      FUN.VALUE = numeric(1)
    ))
  }
  
  # Case 2: numeric vector input
  if (!is.numeric(x)) {
    stop("`x` must be a numeric vector or a data frame.", call. = FALSE)
  }
  
  x <- stats::na.omit(x)
  N <- length(x)
  
  if (N < 4L) {
    warning("skew_zscore requires at least 4 non-missing values; returning NA.")
    return(NA_real_)
  }
  
  if (length(unique(x)) == 1L) {
    warning("skew_zscore requires variation in the data; returning NA.")
    return(NA_real_)
  }
  
  skewness(x) / skew_se(x)
}