#' Detect multivariate outliers using Mahalanobis distance
#'
#' Computes Mahalanobis distance for selected columns and flags observations
#' whose squared distance exceeds the chi-square cutoff.
#'
#' @param df A data frame.
#' @param id_col Optional column name giving sample IDs.
#' @param cols Optional character vector of columns to use. Default is all columns
#'   that are numeric or can be safely converted to numeric.
#' @param alpha Significance level for the chi-square cutoff. Default is 0.001.
#' @param na.rm Logical; if TRUE, remove rows with missing values in selected columns.
#' @param only_outliers Logical; if TRUE, return only flagged outliers.
#' @param coerce_numeric Logical; if TRUE, attempt to convert selected columns to numeric.
#'
#' @return A data frame with row/sample names, Mahalanobis distances, cutoff,
#' and outlier flag.
#'
#' @examples
#' mahalanobis_outliers(iris[, 1:4])
#' mahalanobis_outliers(dat1, cols = colnames(dat1)[1:30])
#'
#' @export
mahalanobis_outliers <- function(df,
                                 id_col = NULL,
                                 cols = NULL,
                                 alpha = 0.001,
                                 na.rm = TRUE,
                                 only_outliers = FALSE,
                                 coerce_numeric = TRUE) {
  
  if (!is.data.frame(df)) {
    stop("`df` must be a data.frame.", call. = FALSE)
  }
  
  if (!is.null(id_col) && !id_col %in% names(df)) {
    stop("`id_col` was not found in `df`.", call. = FALSE)
  }
  
  if (!is.numeric(alpha) || length(alpha) != 1L || alpha <= 0 || alpha >= 1) {
    stop("`alpha` must be one numeric value between 0 and 1.", call. = FALSE)
  }
  
  if (is.null(cols)) {
    cols <- names(df)
  } else {
    if (!all(cols %in% names(df))) {
      missing_cols <- cols[!cols %in% names(df)]
      stop(
        "Some values in `cols` were not found in `df`: ",
        paste(missing_cols, collapse = ", "),
        call. = FALSE
      )
    }
  }
  
  if (length(cols) == 0L) {
    stop("No columns were selected.", call. = FALSE)
  }
  
  X_raw <- df[, cols, drop = FALSE]
  
  if (coerce_numeric) {
    X <- as.data.frame(
      lapply(X_raw, function(x) {
        if (is.factor(x)) {
          x <- as.character(x)
        }
        suppressWarnings(as.numeric(x))
      }),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  } else {
    non_numeric <- !vapply(X_raw, is.numeric, logical(1))
    if (any(non_numeric)) {
      stop(
        "All columns in `cols` must be numeric. Non-numeric columns: ",
        paste(names(X_raw)[non_numeric], collapse = ", "),
        call. = FALSE
      )
    }
    X <- X_raw
  }
  
  # Drop columns that became entirely NA after numeric conversion
  all_na_cols <- vapply(X, function(x) all(is.na(x)), logical(1))
  
  if (any(all_na_cols)) {
    warning(
      "Dropping columns that could not be converted to numeric: ",
      paste(names(X)[all_na_cols], collapse = ", "),
      call. = FALSE
    )
    X <- X[, !all_na_cols, drop = FALSE]
  }
  
  if (ncol(X) == 0L) {
    stop("No usable numeric columns available for Mahalanobis distance.", call. = FALSE)
  }
  
  # Drop zero-variance columns because they break the covariance matrix
  zero_var_cols <- vapply(X, function(x) {
    s <- stats::sd(x, na.rm = TRUE)
    !is.finite(s) || s == 0
  }, logical(1))
  
  if (any(zero_var_cols)) {
    warning(
      "Dropping zero-variance columns: ",
      paste(names(X)[zero_var_cols], collapse = ", "),
      call. = FALSE
    )
    X <- X[, !zero_var_cols, drop = FALSE]
  }
  
  if (ncol(X) == 0L) {
    stop("No usable non-constant numeric columns available.", call. = FALSE)
  }
  
  keep <- stats::complete.cases(X)
  
  if (!na.rm && !all(keep)) {
    stop(
      "Missing values found in selected columns. Set `na.rm = TRUE` to remove them.",
      call. = FALSE
    )
  }
  
  X <- X[keep, , drop = FALSE]
  
  if (nrow(X) < 2L) {
    stop("Not enough complete rows to compute Mahalanobis distance.", call. = FALSE)
  }
  
  if (nrow(X) <= ncol(X)) {
    stop(
      "Not enough complete rows relative to the number of columns. ",
      "Mahalanobis distance needs more complete rows than variables. ",
      "Try fewer columns or remove highly redundant variables.",
      call. = FALSE
    )
  }
  
  idx <- which(keep)
  
  row_names <- rownames(df)[keep]
  
  out_names <- if (!is.null(id_col)) {
    as.character(df[[id_col]][keep])
  } else if (!is.null(rownames(df)) && any(nzchar(rownames(df)))) {
    rownames(df)[keep]
  } else {
    as.character(idx)
  }
  
  center <- colMeans(X)
  cov_mat <- stats::cov(X)
  
  md2 <- tryCatch(
    stats::mahalanobis(X, center = center, cov = cov_mat),
    error = function(e) {
      stop(
        "Covariance matrix could not be inverted. ",
        "This usually means selected columns are perfectly collinear/redundant. ",
        "Try fewer columns or remove duplicate/highly correlated variables.",
        call. = FALSE
      )
    }
  )
  
  p <- ncol(X)
  cutoff <- stats::qchisq(1 - alpha, df = p)
  
  out <- data.frame(
    Index = idx,
    Rowname = row_names,
    Outlier_Name = out_names,
    MD2 = as.numeric(md2),
    MD = sqrt(as.numeric(md2)),
    Cutoff = cutoff,
    Is_Outlier = as.numeric(md2) > cutoff,
    stringsAsFactors = FALSE
  )
  
  out <- out[order(out$MD2, decreasing = TRUE), , drop = FALSE]
  
  if (only_outliers) {
    out <- out[out$Is_Outlier, , drop = FALSE]
  }
  
  rownames(out) <- NULL
  
  attr(out, "columns_used") <- names(X)
  attr(out, "n_columns_used") <- ncol(X)
  attr(out, "n_rows_used") <- nrow(X)
  
  out
}