#' Return only the numeric columns of a data frame
#'
#' Selects and returns only the numeric columns from a data frame.
#' This is useful before applying numeric-only functions such as z-scores,
#' outlier detection, correlations, or summary statistics.
#'
#' @param df A data frame.
#'
#' @return A data frame containing only numeric columns. If there are no numeric
#' columns, returns a data frame with 0 columns and the same number of rows.
#'
#' @examples
#' numeric_df(iris)
#'
#' dat <- data.frame(
#'   id = c("A", "B", "C"),
#'   height = c(60, 65, 70),
#'   weight = c(100, 120, 140)
#' )
#'
#' numeric_df(dat)
#'
#' @export
numeric_df <- function(df) {
  if (!is.data.frame(df)) {
    stop("`df` must be a data.frame", call. = FALSE)
  }
  
  keep <- vapply(df, is.numeric, logical(1))
  
  if (!any(keep)) {
    return(df[ , FALSE, drop = FALSE])
  }
  
  df[ , keep, drop = FALSE]
}