#' Return indices and names of z-score outliers by column
#'
#' Applies the same z-score outlier rule used in the summary output and returns
#' one row per outlier. The number of rows per variable should match the
#' corresponding `Outlier_Count` from `univar_summarize_df()` when the same
#' threshold is used.
#'
#' @param df A data frame.
#' @param threshold Positive numeric; two-sided z cutoff (default 3).
#' @param na.rm Logical; ignore NAs when detecting outliers (default TRUE).
#' @param id_col Optional character string naming an ID column in `df`.
#'   If supplied, this column is used for `Outlier_Name`.
#'
#' @return A data.frame with columns:
#' \describe{
#'   \item{Variable}{Column name}
#'   \item{Index}{Row index in the original data frame}
#'   \item{Outlier_Name}{ID value, row name, or row index}
#'   \item{Value}{Original observed value}
#'   \item{Z}{Z-score}
#' }
#'
#' @examples
#' z_outlier_details_df(iris, threshold = 3)
#'
#' @seealso [zscore()], [num_of_outliers_df()]
#' @export
z_outlier_details_df <- function(df, threshold = 3, na.rm = TRUE, id_col = NULL) {
  if (!is.data.frame(df)) {
    stop("`df` must be a data.frame.", call. = FALSE)
  }

  if (!is.null(id_col) && !id_col %in% names(df)) {
    stop("`id_col` was not found in `df`.", call. = FALSE)
  }

  num <- numeric_df(df)
  if (ncol(num) == 0L) {
    return(data.frame(
      Variable = character(0),
      Index = integer(0),
      Outlier_Name = character(0),
      Value = numeric(0),
      Z = numeric(0),
      stringsAsFactors = FALSE
    ))
  }

  zmat <- as.data.frame(lapply(num, zscore, na.rm = na.rm))

  out_list <- lapply(names(zmat), function(v) {
    z <- zmat[[v]]
    x <- num[[v]]

    flag <- !is.na(z) & abs(z) >= threshold
    if (na.rm) flag[is.na(flag)] <- FALSE

    idx <- which(flag)

    if (length(idx) == 0L) return(NULL)

    out_names <- if (!is.null(id_col)) {
      as.character(df[[id_col]][idx])
    } else if (!is.null(rownames(df)) && any(nzchar(rownames(df)))) {
      rownames(df)[idx]
    } else {
      as.character(idx)
    }

    data.frame(
      Variable = v,
      Index = idx,
      Outlier_Name = out_names,
      Value = x[idx],
      Z = z[idx],
      stringsAsFactors = FALSE
    )
  })

  out <- do.call(rbind, out_list)

  if (is.null(out)) {
    return(data.frame(
      Variable = character(0),
      Index = integer(0),
      Outlier_Name = character(0),
      Value = numeric(0),
      Z = numeric(0),
      stringsAsFactors = FALSE
    ))
  }

  rownames(out) <- NULL
  out
}
