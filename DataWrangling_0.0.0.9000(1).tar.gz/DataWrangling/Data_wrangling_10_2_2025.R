
library(DataWrangling)

dat1<- read.csv("/Users/saara1/Desktop/DataWrangling/FS6_Stats_ASD_Destrieux_112222_subset.csv", row.names=1, check.names = FALSE)
dat1 <- as.data.frame(dat1)

univar_visualize_df(
  dat1,
  show_plots = FALSE,
  save_pdf = TRUE,
  out_dir = "~/Desktop",
  prefix = "ADRC_univar",
  hist_nrow = 4,
  hist_ncol = 5
)
zscore(apply(dat1,2,as.numeric),row_names = rownames(dat1))
column_zscore(dat1)


mah30 <- mahalanobis_outliers(
  dat1,
  cols = colnames(dat1)[1:30],
  alpha = 0.001,
  only_outliers = FALSE
)

plot_mahalanobis_2d(
  dat1,
  colnames(dat1)[1],
  colnames(dat1)[2],
  alpha = 0.001
)


head(mah30)

head(zdat1)
rownames(zdat1)
first_num_var <- names(numeric_df(dat1))[1]

z_outlier_details_df(dat1, threshold = 3)[
  z_outlier_details_df(dat1, threshold = 3)$Variable == first_num_var,
]

DataWrangling::column_zscore(dat1)
DataWrangling::numeric_df(dat1)

DataWrangling::univar_visualize_df(dat1)
DataWrangling::z_outlier(dat1)


DataWrangling::univar_visualize_df(dat1)

DataWrangling::skew_se(dat1)
DataWrangling::z_outlier()

DataWrangling::skewness(dat1)
DataWrangling::skew_zscore(dat1)

DataWrangling::safe_shapiro_pval(dat1)
DataWrangling::num_of_outliers_df(dat1)

DataWrangling::skew_zscore(dat1)

DataWrangling::univar_summarize_df(dat1$R_Amg_Vol)

res <- DataWrangling::z_outlier_details_df(dat1, threshold = 3)
res

DataWrangling::z_outlier_details_df(dat1)


DataWrangling::skewness(dat1$L_Lateral_Ventricle_Vol)
sumtable <- DataWrangling::univar_summarize_df(dat1)

DataWrangling::mahalanobis_outliers(
  df = dat1,
  cols = c("L_Tha_Vol", "R_Tha_Vol")
)

DataWrangling::plot_mahalanobis_2d(
  df = dat1,
  x = "L_Tha_Vol",
  y = "R_Tha_Vol",
  alpha = 0.001
)


# Skewness helper functions
skewness <- function(x) {
  x <- na.omit(x)
  N <- length(x)
  numerator <- sum((x - mean(x))^3) / N
  denominator <- (sqrt(sum((x - mean(x))^2) / N))^3
  skew <- numerator / denominator
  skew
}

skew_se <- function(x) {
  N <- length(na.omit(x))
  sqrt(6 * N * (N - 1) / ((N - 2) * (N + 1) * (N + 3)))
}

skew_zscore <- function(x) {
  skewness(x) / skew_se(x)
}

numeric_df <- function(x) {
  select_if(x, is.numeric)
}

# Helper functions for outlier detection, normality test, etc.
zscore <- function(x) {
  (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE)
}

z_outlier <- function(x) {
  sum(x > 3 | x < -3, na.rm = TRUE)
}

num_of_outliers_Real <- function(df) {
  num_df <- numeric_df(df)
  z_scores <- as.data.frame(lapply(num_df, zscore))
  sapply(z_scores, z_outlier)
}

safe_shapiro_pval <- function(x) {
  if (any(is.na(x))) return(NA)
  if (length(x) < 3) return(NA)
  if (length(unique(x)) == 1) return(NA)
  shapiro.test(x)$p.value
}

# Calculate skewness z-scores for numeric columns
compute_skew_zscores <- function(df) {
  num_df <- numeric_df(df)
  sapply(num_df, skew_zscore)
}

shapiro_pvalues <- sapply(dat1, safe_shapiro_pval)
skew_zscores <- compute_skew_zscores(dat1)
raw_skew <- sapply(numeric_df(dat1), skewness)

##### Modify into a function
summary_stats <- data.frame(
  Variable = names(dat1),
  Min = sapply(dat1, min, na.rm = TRUE),
  Max = sapply(dat1, max, na.rm = TRUE),
  Range = sapply(dat1, function(x) diff(range(x, na.rm = TRUE))),
  Median = sapply(dat1, median, na.rm = TRUE),
  IQR = sapply(dat1, IQR, na.rm = TRUE),
  Zero_Percent = sapply(dat1, function(x) 100 * sum(x == 0, na.rm = TRUE) / sum(!is.na(x))),
  Missing_Count = sapply(dat1, function(x) sum(is.na(x))),
  Has_Duplicates = any(duplicated(dat1)),
  Outlier_Count = num_of_outliers_Real(dat1),
  Is_Normal = NA,      # To be updated
  Skewness = NA,       # To be updated
  Is_Skewed = NA       # To be updated
)

numeric_vars <- names(numeric_df(dat1))

summary_stats$Is_Normal[summary_stats$Variable %in% numeric_vars] <- shapiro_pvalues > 0.05
summary_stats$Skewness[summary_stats$Variable %in% numeric_vars] <- raw_skew
summary_stats$Is_Skewed[summary_stats$Variable %in% numeric_vars] <- abs(skew_zscores) > 3

print(summary_stats)
write.csv(summary_stats, file = "~/Downloads/summary_stats.csv")

#### Flag
# example:


# Visualizations
boxplot(dat1, las = 2, main = "Boxplots for Each Variable")
barplot(summary_stats$Zero_Percent, names.arg = summary_stats$Variable, las = 2,
        main = "Percent of Zeros per Variable", ylab = "Percent (%)", col = "tomato")

par(mfrow = c(4, 5))
for (v in names(dat1)) {
  hist(dat1[[v]], main = paste("Histogram of", v), xlab = v, col = "lightblue")
}
par(mfrow = c(1, 1))


# Save boxplot as PDF
pdf("boxplots_each_variable.pdf", width = 12, height = 8)  # size in inches
boxplot(dat1, las = 2, main = "Boxplots for Each Variable")
dev.off()

# Save zero percent barplot as PDF
pdf("~/Downloads/zero_percent_barplot.pdf", width = 12, height = 8)
barplot(summary_stats$Zero_Percent, names.arg = summary_stats$Variable, las = 2,
        main = "Percent of Zeros per Variable", ylab = "Percent (%)", col = "tomato")
dev.off()

# Save histograms to a multipage PDF, 20 plots per page (4x5 layout)
pdf("~/Downloads/histograms_each_variable.pdf", width = 12, height = 10)
par(mfrow = c(4, 5))
for (v in names(dat1)) {
  hist(dat1[[v]], main = paste("Histogram of", v), xlab = v, col = "lightblue")
}
par(mfrow = c(1, 1))  # reset
dev.off()
